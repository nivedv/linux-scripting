=================================================================
MODULE 3: REGULAR EXPRESSIONS - DEEP DIVE
Demo Files Package
=================================================================

CONTENTS:
---------
1. system.log            - System and application logs (30 lines)
2. access.log            - Apache web server access logs (20 lines)
3. email_list.txt        - Sample email addresses (valid & invalid, 20 entries)
4. servers.txt           - Server inventory list (15 servers)
5. config.conf           - Sample configuration file with various settings
6. passwd.txt            - User accounts in passwd format (15 users)
7. firewall_rules.txt    - Firewall rules (15 rules)
8. setup_demo.sh         - Automated setup script
9. README.txt            - This file

=================================================================
QUICK START:
=================================================================

Option 1: AUTOMATED SETUP (Recommended)
----------------------------------------
1. Extract this zip file:
   unzip module3_demo_files.zip

2. Navigate to the directory:
   cd module3_demo_files

3. Run the setup script:
   bash setup_demo.sh

4. Follow the trainer demo guide!


Option 2: MANUAL SETUP
----------------------
1. Extract the zip file wherever you want:
   unzip module3_demo_files.zip -d ~/module3_demo

2. Navigate to the directory:
   cd ~/module3_demo

3. Verify all files are present:
   ls -lh

4. Start practicing!


=================================================================
FILE DESCRIPTIONS:
=================================================================

system.log
----------
Real-world system log entries including:
- SSH authentication attempts (successful and failed)
- Apache web server access entries  
- Mail server events (postfix, dovecot)
- Database errors and warnings (MySQL)
- Firewall/kernel messages
- Various IP addresses and usernames

Use cases:
- IP address extraction
- Failed login detection
- Security audit (brute force attacks)
- Log parsing and pattern matching


access.log
----------
Apache web server access log in Common Log Format:
- Various HTTP methods (GET, POST, DELETE)
- Different status codes (200, 201, 304, 401, 403, 404, 500)
- Multiple user agents (browsers, bots, scripts)
- Suspicious patterns (path traversal, admin access attempts)
- Authenticated and unauthenticated requests

Use cases:
- Status code analysis
- Error detection (4xx, 5xx)
- Attack pattern identification
- User agent extraction
- URL path analysis


email_list.txt
--------------
Mix of valid and invalid email addresses:
- Proper format: user@domain.com
- Invalid formats: missing @, no TLD, double dots, etc.

Use cases:
- Email validation
- Pattern matching practice
- Data quality checking
- grep -v for finding invalid entries


servers.txt
-----------
Server inventory with tab/space-delimited fields:
- Hostname
- IP address
- OS version
- RAM
- Status (active/maintenance/inactive)

Use cases:
- IP extraction and validation
- Hostname validation
- Data filtering by status
- Inventory management


config.conf
-----------
Application configuration file containing:
- IP addresses and ports
- Email addresses (admin, support, alerts)
- File paths (logs, data)
- Database credentials
- Phone numbers
- Various parameters

Use cases:
- Email extraction
- IP address extraction
- Path validation
- Configuration auditing
- Parameter extraction


passwd.txt
----------
User account file in /etc/passwd format:
- Username:x:UID:GID:Comment:Home:Shell
- Mix of system users and regular users
- Different shells (/bin/bash, /bin/zsh, /bin/false, /usr/sbin/nologin)

Use cases:
- Username extraction
- Shell type analysis
- UID/GID parsing
- User account validation
- Home directory extraction


firewall_rules.txt
------------------
iptables-style firewall rules:
- ACCEPT and DROP rules
- Various protocols (TCP, UDP, ICMP)
- Port specifications
- IP address ranges (CIDR notation)

Use cases:
- Rule parsing
- IP address extraction
- Port number extraction
- Security policy analysis
- Rule validation


=================================================================
DEMO EXERCISES:
=================================================================

DEMO 1: EMAIL AND IP EXTRACTION
--------------------------------
# Extract all email addresses from config
grep -oE '[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' config.conf

# Find valid emails in email list
grep -E '^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$' email_list.txt

# Find INVALID emails
grep -vE '^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$' email_list.txt

# Extract all IP addresses from system log
grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' system.log

# Find unique IPs with count
grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' system.log | sort | uniq -c | sort -rn


DEMO 2: LOG PARSING
--------------------
# Find failed SSH login attempts
grep 'Failed password' system.log

# Extract usernames from failed logins
grep -oP 'Failed password for \K\w+' system.log

# Find HTTP errors (4xx and 5xx)
grep -E ' [45][0-9]{2} ' access.log

# Count error types
grep -oE ' [45][0-9]{2} ' access.log | sort | uniq -c | sort -rn

# Find directory traversal attacks
grep -E '\.\.\/' access.log

# Extract suspicious URLs
grep -E '(admin|shell|wp-admin|xmlrpc)' access.log


DEMO 3: DATA VALIDATION
------------------------
# Validate server hostnames (5-20 chars, start with letter)
grep -E '^[a-zA-Z][a-zA-Z0-9-]{4,19} ' servers.txt

# Find invalid hostnames
grep -vE '^[a-zA-Z][a-zA-Z0-9-]{4,19} ' servers.txt

# Extract IP addresses from server list
grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' servers.txt

# Validate usernames in passwd file (lowercase, 3-32 chars)
grep -E '^[a-z0-9._]{3,32}:' passwd.txt

# Extract users with bash shell
grep '/bin/bash$' passwd.txt


DEMO 4: REAL-WORLD APPLICATIONS
--------------------------------
# Security audit - find brute force IPs (3+ failed attempts)
grep 'Failed password' system.log | grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' | sort | uniq -c | awk '$1 >= 3 {print $2, "("$1" attempts)"}'

# Generate iptables ban commands
grep 'Failed password' system.log | grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' | sort | uniq -c | awk '$1 >= 3 {print "iptables -A INPUT -s "$2" -j DROP"}'

# Extract all unique emails for config update
grep -oE '[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' config.conf | sort -u

# Find large HTTP responses (>50KB)
grep -E '" [0-9]{3} [5-9][0-9]{4,}' access.log

# List SSH ACCEPT rules
grep -E '^ACCEPT.*dpt:22' firewall_rules.txt

# Find blocked IPs
grep -E '^DROP' firewall_rules.txt | grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}[^ ]*'


=================================================================
REGEX PATTERNS REFERENCE:
=================================================================

Email Address:
[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}

IP Address (format):
\b([0-9]{1,3}\.){3}[0-9]{1,3}\b

IP Address (validated 0-255):
\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b

Phone Number (XXX-XXX-XXXX):
\d{3}-\d{3}-\d{4}

Date (YYYY-MM-DD):
[0-9]{4}-[0-9]{2}-[0-9]{2}

URL:
https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[/a-zA-Z0-9._?=-]*

MAC Address:
([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}


=================================================================
GREP FLAGS REFERENCE:
=================================================================

-E    Extended regex (recommended for most patterns)
-P    Perl regex (advanced features like \K)
-o    Only show matching part (not whole line)
-v    Invert match (show non-matching lines)
-i    Case insensitive
-n    Show line numbers
-c    Count matches only
-l    Show only filenames with matches
-h    Don't show filenames
-r    Recursive search


=================================================================
TROUBLESHOOTING:
=================================================================

Problem: "Pattern doesn't match anything"
Solution: - Start simple, build incrementally
          - Check grep flavor (-E vs -P)
          - Escape special characters (. $ * + ?)
          - Test on simple input first

Problem: "Pattern matches too much"
Solution: - Add anchors (^ for start, $ for end)
          - Use word boundaries (\b)
          - Make quantifiers non-greedy (.*? instead of .*)

Problem: "Can't extract just the match"
Solution: - Use -o flag with grep
          - Use capture groups with sed
          - Use \K with grep -P

Problem: "grep returns nothing but data is there"
Solution: - Check file encoding: file filename.txt
          - Check for hidden characters: cat -A filename.txt
          - Verify pattern: echo "test" | grep -E 'pattern'

Problem: "Need to match literal special character"
Solution: - Escape with backslash: \. \$ \* \+ \?
          - For lots of specials, use fgrep (no regex)


=================================================================
BEST PRACTICES:
=================================================================

1. Start Simple: Begin with literal text, add patterns incrementally
2. Test Often: Test pattern after each change
3. Use Online Tools: regex101.com or regexr.com for visualization
4. Anchor Patterns: Use ^ and $ to ensure complete matches
5. Word Boundaries: Use \b to match whole words only
6. Save Patterns: Keep a cheat sheet of common patterns
7. Comment Complex: Document what complex patterns do
8. Validate Results: Check output, don't assume pattern is correct


=================================================================
ADDITIONAL RESOURCES:
=================================================================

Documentation:
- man grep        (grep manual)
- man regex       (regex manual)
- man sed         (sed manual)

Online Resources:
- regex101.com    (Interactive regex tester)
- regexr.com      (Visual regex builder)
- https://www.gnu.org/software/grep/manual/
- https://www.regular-expressions.info/


=================================================================
TRAINER NOTES:
=================================================================

This package includes all files needed for Module 3 demonstrations.

Recommended setup:
1. Extract in student VMs before class starts
2. Have students verify files: ls -lh ~/module3_demo
3. Run setup script to validate environment
4. Keep demo guide open for reference

Time allocation:
- Demo 1 (Email/IP): 5 minutes
- Demo 2 (Log parsing): 5 minutes
- Demo 3 (Validation): 5 minutes
- Demo 4 (Real-world): 5 minutes
- Total: 20 minutes

After demos, students proceed to hands-on labs.

Key teaching points:
- Regex is patterns, not magic
- Build incrementally, test frequently
- Anchors and boundaries are critical
- Capture groups enable extraction
- -v flag finds what DOESN'T match


=================================================================
VERSION INFORMATION:
=================================================================

Package Version: 1.0
Created: November 2024
Module: 3 - Regular Expressions Deep Dive
Target: System Administrators and IT Professionals
Focus: Real-world log parsing, security, and automation

=================================================================
