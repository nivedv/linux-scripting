#!/bin/bash
#############################################################################
# Module 3 Demo Environment Setup Script
# Regular Expressions - Deep Dive
#############################################################################

echo "=========================================="
echo "Module 3: Regular Expressions Deep Dive"
echo "Demo Environment Setup"
echo "=========================================="
echo ""

# Get current directory
DEMO_DIR=$(pwd)

echo "Setting up demo environment in: $DEMO_DIR"
echo ""

# Check if all required files exist
echo "Checking for required files..."
REQUIRED_FILES=(
    "system.log"
    "access.log"
    "email_list.txt"
    "servers.txt"
    "config.conf"
    "passwd.txt"
    "firewall_rules.txt"
)

MISSING_FILES=0
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✓ $file found"
    else
        echo "  ✗ $file MISSING"
        MISSING_FILES=$((MISSING_FILES + 1))
    fi
done

echo ""

if [ $MISSING_FILES -gt 0 ]; then
    echo "ERROR: $MISSING_FILES file(s) missing!"
    echo "Please ensure all files were extracted properly."
    exit 1
fi

echo "All required files present!"
echo ""

# Display file information
echo "File Information:"
echo "----------------------------------------"
ls -lh | grep -v "^total" | grep -v "^d" | grep -v "setup_demo.sh"
echo ""

# Verify file contents
echo "Verifying file contents..."
echo ""

# Check system.log
LOG_LINES=$(wc -l < system.log)
echo "  system.log: $LOG_LINES lines"

# Check access.log
ACCESS_LINES=$(wc -l < access.log)
echo "  access.log: $ACCESS_LINES lines"

# Check email_list.txt
EMAIL_LINES=$(wc -l < email_list.txt)
echo "  email_list.txt: $EMAIL_LINES email addresses"

# Check servers.txt
SERVER_LINES=$(wc -l < servers.txt)
echo "  servers.txt: $SERVER_LINES servers"

# Check config.conf
CONFIG_LINES=$(wc -l < config.conf)
echo "  config.conf: $CONFIG_LINES lines"

# Check passwd.txt
PASSWD_LINES=$(wc -l < passwd.txt)
echo "  passwd.txt: $PASSWD_LINES user accounts"

# Check firewall_rules.txt
FW_LINES=$(wc -l < firewall_rules.txt)
echo "  firewall_rules.txt: $FW_LINES firewall rules"

echo ""

# Test basic commands
echo "Testing grep capabilities..."
echo ""

# Test extended regex
if echo "test123" | grep -qE '[0-9]+'; then
    echo "  ✓ Extended regex (-E) supported"
else
    echo "  ✗ WARNING: Extended regex not working!"
fi

# Test Perl regex
if echo "test123" | grep -qP '\d+' 2>/dev/null; then
    echo "  ✓ Perl regex (-P) supported"
else
    echo "  ⚠ WARNING: Perl regex not supported (some demos may need adjustments)"
fi

# Test -o flag
if echo "test@example.com" | grep -oE '@' >/dev/null 2>&1; then
    echo "  ✓ Output only matching (-o) supported"
else
    echo "  ✗ WARNING: -o flag not working!"
fi

echo ""

# Quick data validation tests
echo "Running quick validation tests..."
echo ""

# Test 1: Can we extract IPs?
IP_COUNT=$(grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' system.log 2>/dev/null | wc -l)
if [ $IP_COUNT -gt 0 ]; then
    echo "  ✓ IP extraction test passed ($IP_COUNT IPs found)"
else
    echo "  ✗ IP extraction test failed"
fi

# Test 2: Can we extract emails?
EMAIL_COUNT=$(grep -oE '[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' config.conf 2>/dev/null | wc -l)
if [ $EMAIL_COUNT -gt 0 ]; then
    echo "  ✓ Email extraction test passed ($EMAIL_COUNT emails found)"
else
    echo "  ✗ Email extraction test failed"
fi

# Test 3: Can we find failed logins?
FAILED_COUNT=$(grep -c 'Failed password' system.log 2>/dev/null)
if [ $FAILED_COUNT -gt 0 ]; then
    echo "  ✓ Log parsing test passed ($FAILED_COUNT failed logins found)"
else
    echo "  ✗ Log parsing test failed"
fi

# Test 4: Can we find HTTP errors?
ERROR_COUNT=$(grep -cE ' [45][0-9]{2} ' access.log 2>/dev/null)
if [ $ERROR_COUNT -gt 0 ]; then
    echo "  ✓ HTTP error detection passed ($ERROR_COUNT errors found)"
else
    echo "  ✗ HTTP error detection failed"
fi

echo ""

# Create a quick reference file
echo "Creating regex_cheatsheet.txt..."
cat > regex_cheatsheet.txt << 'CHEATSHEET'
=================================================================
REGEX QUICK REFERENCE CHEAT SHEET
=================================================================

METACHARACTERS:
---------------
.       Any single character
^       Start of line
$       End of line
*       0 or more (greedy)
+       1 or more (greedy)
?       0 or 1 (optional) OR make quantifier non-greedy
[]      Character class (any one of these)
[^]     Negated class (none of these)
()      Capture group
|       OR
\       Escape special character
\b      Word boundary

QUANTIFIERS:
------------
*       0 or more
+       1 or more
?       0 or 1
{n}     Exactly n times
{n,}    n or more times
{n,m}   Between n and m times

Add ? after quantifier for non-greedy: .*? .+? {n,m}?

SHORTCUTS (use with -P for Perl regex):
----------------------------------------
\d      Digit [0-9]
\D      NOT digit
\w      Word character [a-zA-Z0-9_]
\W      NOT word character
\s      Whitespace (space, tab, newline)
\S      NOT whitespace

COMMON PATTERNS:
----------------
Email:
[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}

IP Address:
\b([0-9]{1,3}\.){3}[0-9]{1,3}\b

Phone (XXX-XXX-XXXX):
\d{3}-\d{3}-\d{4}

Date (YYYY-MM-DD):
[0-9]{4}-[0-9]{2}-[0-9]{2}

GREP FLAGS:
-----------
-E      Extended regex (recommended)
-P      Perl regex (advanced)
-o      Only show matching part
-v      Invert (show non-matching)
-i      Case insensitive
-n      Show line numbers
-c      Count matches only

EXAMPLES:
---------
# Extract all emails
grep -oE '[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' file.txt

# Extract all IPs
grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' file.txt

# Find HTTP errors
grep -E ' [45][0-9]{2} ' access.log

# Extract username after "user="
grep -oP 'user=\K\w+' logfile

# Find lines starting with ERROR
grep '^ERROR' logfile

# Find lines ending with .com
grep '\.com$' file.txt

# Find valid emails only
grep -E '^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$' emails.txt

# Find INVALID emails
grep -vE '^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$' emails.txt

=================================================================
CHEATSHEET
echo "  ✓ Created regex_cheatsheet.txt"

echo ""
echo "=========================================="
echo "Setup Complete!"
echo "=========================================="
echo ""
echo "You are ready to start the demos!"
echo ""
echo "Quick test commands:"
echo "  1. Extract IPs: grep -oE '\\b([0-9]{1,3}\\.){3}[0-9]{1,3}\\b' system.log"
echo "  2. Extract emails: grep -oE '[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}' config.conf"
echo "  3. Find failed logins: grep 'Failed password' system.log"
echo "  4. Find HTTP errors: grep -E ' [45][0-9]{2} ' access.log"
echo ""
echo "For full demo instructions, see the Module 3 Trainer Demo Guide"
echo ""
echo "Cheat sheet created: regex_cheatsheet.txt"
echo ""
echo "Current directory: $DEMO_DIR"
echo ""
echo "Happy regex learning!"
echo ""
